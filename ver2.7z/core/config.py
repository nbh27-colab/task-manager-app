# crud_app/core/config.py

from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional

class Settings(BaseSettings):
    """
    Application settings loaded from environment variables or .env file.
    """
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8')

    # Security settings
    SECRET_KEY: str = "my-secure-dev-key" # IMPORTANT: CHANGE THIS IN PRODUCTION!
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30

    # Database settings (if you need to externalize this later)
    # SQLALCHEMY_DATABASE_URL: str = "sqlite:///./sql_app.db"

settings = Settings()
