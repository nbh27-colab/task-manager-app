# crud_app/services/task_service.py

from sqlalchemy.orm import Session
from typing import Optional, List, Dict, Any

from database import crud, models, vectordb
from api.schemas.task import TaskCreate, TaskUpdate, TaskTimeEstimation
from api.schemas.ai import TaskSuggestionRequest, TaskSuggestionResponse # Import new AI schemas

# NEW IMPORTS for AI modules
from ai.models.time_estimator import TimeEstimatorModel
from ai.features import extract_task_features


class TaskService:
    """
    Service layer for handling task-related business logic,
    including CRUD operations and AI integrations.
    """

    def __init__(self, db: Session):
        self.db = db
        # Initialize AI models (can be singleton or passed in via dependency injection in larger apps)
        self.time_estimator_model = TimeEstimatorModel()

    def create_task(self, task: TaskCreate, user_id: int) -> models.Task:
        """
        Creates a new task.
        Can include initial AI suggestions if desired.
        """
        # --- Basic task creation logic (similar to existing crud) ---
        db_task = crud.create_user_task(self.db, task=task, user_id=user_id)

        # --- AI Integration: Add task to Vector DB for future suggestions ---
        # Ensure description is not None before adding
        task_text = f"{db_task.title} {db_task.description or ''}".strip()
        if task_text:
            # Prepare metadata for ChromaDB
            metadata = {
                "owner_id": db_task.owner_id,
                "task_id": db_task.id,
                "project_id": db_task.project_id,
                "category_id": db_task.category_id,
                "priority": db_task.priority,
                "status": db_task.status,
                "tags": db_task.tags,
            }
            vectordb.add_task_embedding(
                task_id=db_task.id,
                task_text=task_text,
                owner_id=db_task.owner_id, # Pass owner_id separately as per vectordb.py signature
                metadata=metadata
            )

        return db_task

    def get_task(self, task_id: int) -> Optional[models.Task]:
        """Retrieves a single task by ID."""
        return crud.get_task(self.db, task_id=task_id)

    def get_tasks_for_user(self, user_id: int, skip: int = 0, limit: int = 100) -> List[models.Task]:
        """Retrieves all tasks for a specific user."""
        return crud.get_user_tasks(self.db, user_id=user_id, skip=skip, limit=limit)

    def update_task(self, task_id: int, task_update: TaskUpdate) -> Optional[models.Task]:
        """
        Updates an existing task.
        Can include re-embedding if title/description changes.
        """
        db_task = crud.update_task(self.db, task_id=task_id, task_update=task_update)

        # --- AI Integration: Re-embed if relevant fields changed ---
        if db_task and (task_update.title is not None or task_update.description is not None or
                        task_update.category_id is not None or task_update.project_id is not None or
                        task_update.tags is not None):
            # Fetch updated values for embedding
            updated_title = task_update.title if task_update.title is not None else db_task.title
            updated_description = task_update.description if task_update.description is not None else db_task.description
            
            task_text = f"{updated_title} {updated_description or ''}".strip()
            if task_text:
                # Prepare updated metadata for ChromaDB
                updated_metadata = {
                    "owner_id": db_task.owner_id,
                    "task_id": db_task.id,
                    "project_id": task_update.project_id if task_update.project_id is not None else db_task.project_id,
                    "category_id": task_update.category_id if task_update.category_id is not None else db_task.category_id,
                    "priority": task_update.priority if task_update.priority is not None else db_task.priority, # Use updated priority if available
                    "status": task_update.status if task_update.status is not None else db_task.status,
                    "tags": task_update.tags if task_update.tags is not None else db_task.tags,
                }
                vectordb.update_task_embedding(
                    task_id=db_task.id,
                    new_task_text=task_text,
                    owner_id=db_task.owner_id, # Pass owner_id separately as per vectordb.py signature
                    new_metadata=updated_metadata
                )
        return db_task

    def delete_task(self, task_id: int) -> Optional[models.Task]:
        """Deletes a task by ID."""
        # --- AI Integration: Remove from Vector DB ---
        vectordb.delete_task_embedding(task_id) 
        return crud.delete_task(self.db, task_id=task_id)

    # --- AI Integration Methods ---

    def get_ai_suggestions_for_task(self, request: TaskSuggestionRequest, user_id: int) -> TaskSuggestionResponse:
        """
        Provides AI-driven suggestions for task attributes based on title and description.
        """
        print(f"DEBUG: Generating AI suggestions for user {user_id} with title: {request.title}")

        # Query similar tasks from ChromaDB
        query_text = f"{request.title} {request.description or ''}".strip()
        similar_tasks_results = vectordb.query_similar_tasks(
            query_text=query_text,
            n_results=3,
            owner_id=user_id
        )

        suggested_category_id: Optional[int] = None
        suggested_project_id: Optional[int] = None
        suggested_tags: Optional[str] = None
        suggested_priority: Optional[int] = None
        confidence = 0.0

        if similar_tasks_results:
            # Simple aggregation heuristic:
            # - For category/project/priority, take the most frequent one among top results.
            # - For tags, combine unique tags.
            
            category_ids = [res['metadata'].get('category_id') for res in similar_tasks_results if res['metadata'].get('category_id')]
            project_ids = [res['metadata'].get('project_id') for res in similar_tasks_results if res['metadata'].get('project_id')]
            priorities = [res['metadata'].get('priority') for res in similar_tasks_results if res['metadata'].get('priority')]
            all_tags = []
            for res in similar_tasks_results:
                tags_str = res['metadata'].get('tags')
                if tags_str:
                    all_tags.extend([tag.strip() for tag in tags_str.split(',') if tag.strip()])

            # Find most common category/project/priority
            if category_ids:
                suggested_category_id = max(set(category_ids), key=category_ids.count)
            if project_ids:
                suggested_project_id = max(set(project_ids), key=project_ids.count)
            if priorities:
                suggested_priority = int(round(sum(priorities) / len(priorities))) # Average priority

            if all_tags:
                suggested_tags = ", ".join(sorted(list(set(all_tags)))) # Unique and sorted

            # Confidence based on distance (closer distance = higher confidence)
            # Assuming distance is lower for more similar items
            avg_distance = sum(res['distance'] for res in similar_tasks_results) / len(similar_tasks_results)
            # Invert distance to get confidence (e.g., 1 - normalized_distance)
            # Max distance can vary, so a simple heuristic for now.
            confidence = max(0.0, 1.0 - (avg_distance / 0.5)) # Assuming 0.5 is a typical max distance for "similar"

            print(f"DEBUG: Found similar tasks. Aggregated suggestions: Category={suggested_category_id}, Project={suggested_project_id}, Priority={suggested_priority}, Tags={suggested_tags}, Confidence={confidence:.2f}")

        return TaskSuggestionResponse(
            category_id=suggested_category_id,
            project_id=suggested_project_id,
            tags=suggested_tags,
            priority=suggested_priority,
            urgency_score=None, # To be implemented with a real AI model
            importance_score=None, # To be implemented with a real AI model
            confidence_score=confidence
        )


    def estimate_task_completion_time(self, task_data: TaskCreate, user_id: int) -> TaskTimeEstimation:
        """
        Estimates the completion time for a task using an AI model.
        """
        print(f"DEBUG: Estimating time for task '{task_data.title}' for user {user_id}.")

        # 1. Extract features from task_data
        # Convert TaskCreate to a dictionary for feature extraction
        task_data_dict = task_data.model_dump()
        # Add current priority if it's not in TaskCreate (e.g., if it's a default)
        if 'priority' not in task_data_dict or task_data_dict['priority'] is None:
            task_data_dict['priority'] = 5 # Default priority for new tasks
        
        features = extract_task_features(task_data_dict)

        # 2. Use the initialized AI model to predict time
        estimated_time = self.time_estimator_model.predict(features)
        confidence = self.time_estimator_model.get_confidence(features)
        
        return TaskTimeEstimation(
            ai_estimated_time_hours=estimated_time,
            confidence_score=confidence
        )

    def update_task_ai_estimated_time(self, task_id: int, ai_estimated_time_hours: float, confidence_score: Optional[float] = None) -> Optional[models.Task]:
        """
        Updates the AI-estimated time for a task in the database.
        """
        # Note: crud.update_task_ai_estimated_time currently only takes ai_estimated_time_hours
        # You might need to update crud.py to also accept confidence_score if you want to store it.
        return crud.update_task_ai_estimated_time(self.db, task_id=task_id, ai_estimated_time_hours=ai_estimated_time_hours)

    def update_task_urgency_importance(self, task_id: int, urgency_score: float, importance_score: float, priority: int) -> Optional[models.Task]:
        """
        Updates urgency, importance, and priority scores of a task (typically by AI).
        """
        return crud.update_task_urgency_importance(self.db, task_id=task_id, urgency_score=urgency_score, importance_score=importance_score, priority=priority)

